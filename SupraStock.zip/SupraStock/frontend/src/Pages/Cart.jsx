import React from 'react'
import Cartitems from '../Components/Cartitems/Cartitems'

const Cart = () => {
  return (
    <div>
      <Cartitems/>
    </div>
  )
}

export default Cart
